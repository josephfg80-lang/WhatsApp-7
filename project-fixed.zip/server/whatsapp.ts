import pkg from 'whatsapp-web.js';
const { Client, LocalAuth } = pkg;
// @ts-ignore
import qrcode from 'qrcode-terminal';
import { log } from './vite';
import { storage } from './storage';
import { promises as fs } from 'fs';
import { join } from 'path';

type WhatsAppClient = InstanceType<typeof Client>;

interface ClientState {
  client: WhatsAppClient;
  isReady: boolean;
  qrCode: string | null;
  lastError: string | null;
  lastReadyAt: Date | null;
  initializing: boolean;
}

class WhatsAppClientsManager {
  private clients: Map<string, ClientState> = new Map();
  private initializationLocks: Map<string, Promise<void>> = new Map();

  async initializeAccount(sessionId: string): Promise<void> {
    if (this.initializationLocks.has(sessionId)) {
      log(`Account ${sessionId} is already being initialized, waiting...`);
      await this.initializationLocks.get(sessionId);
      return;
    }

    if (this.clients.has(sessionId)) {
      log(`Account ${sessionId} already initialized`);
      return;
    }

    const initPromise = this._doInitialize(sessionId);
    this.initializationLocks.set(sessionId, initPromise);

    try {
      await initPromise;
    } finally {
      this.initializationLocks.delete(sessionId);
    }
  }

  private async _doInitialize(sessionId: string): Promise<void> {
    log(`Initializing WhatsApp client for session: ${sessionId}`);

    const clientState: ClientState = {
      client: null as any,
      isReady: false,
      qrCode: null,
      lastError: null,
      lastReadyAt: null,
      initializing: true,
    };

    this.clients.set(sessionId, clientState);

    try {
      const client = new Client({
        authStrategy: new LocalAuth({
          clientId: sessionId,
          dataPath: './.wwebjs_auth'
        }),
        puppeteer: {
          headless: true,
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--no-first-run',
            '--no-zygote',
            '--disable-gpu',
            '--single-process',
            '--no-default-browser-check',
            '--disable-extensions',
            '--disable-background-timer-throttling',
            '--disable-backgrounding-occluded-windows',
            '--disable-renderer-backgrounding',
            '--disable-features=site-per-process'
          ],
          timeout: 0
        },
        webVersionCache: {
          type: 'remote',
          remotePath: 'https://raw.githubusercontent.com/wppconnect-team/wa-version/main/html/2.2412.54.html',
        }
      });

      clientState.client = client;

      client.on('qr', (qr: string) => {
        log(`[${sessionId}] QR Code received`);
        qrcode.generate(qr, { small: true });
        clientState.qrCode = qr;
        clientState.isReady = false;
      });

      client.on('ready', async () => {
        log(`[${sessionId}] ✓ Client is ready!`);
        clientState.isReady = true;
        clientState.qrCode = null;
        clientState.lastReadyAt = new Date();
        clientState.initializing = false;

        try {
          const info = await client.info;
          const phoneNumber = info?.wid?.user || null;
          
          const account = await storage.getWhatsAppAccountBySessionId(sessionId);
          if (account) {
            await storage.updateWhatsAppAccount(account.id, {
              isConnected: true,
              phoneNumber: phoneNumber,
              lastUsedAt: new Date(),
            });
          }
        } catch (error: any) {
          log(`[${sessionId}] Error updating account info: ${error.message}`);
        }
      });

      client.on('authenticated', () => {
        log(`[${sessionId}] ✓ Authenticated successfully!`);
      });

      client.on('auth_failure', async (message: string) => {
        log(`[${sessionId}] ✗ Authentication failure: ${message}`);
        clientState.isReady = false;
        clientState.lastError = `Authentication failed: ${message}`;
        clientState.initializing = false;

        const account = await storage.getWhatsAppAccountBySessionId(sessionId);
        if (account) {
          await storage.updateWhatsAppAccount(account.id, {
            isConnected: false,
          });
        }

        log(`[${sessionId}] Deleting old session and reinitializing...`);
        try {
          await client.destroy();
        } catch (e: any) {
          log(`[${sessionId}] Error destroying client: ${e.message}`);
        }

        this.clients.delete(sessionId);

        try {
          const authPath = join(process.cwd(), '.wwebjs_auth', `session-${sessionId}`);
          await fs.rm(authPath, { recursive: true, force: true });
          log(`[${sessionId}] Deleted old session files`);
        } catch (error: any) {
          log(`[${sessionId}] Error deleting session files: ${error.message}`);
        }

        setTimeout(async () => {
          log(`[${sessionId}] Reinitializing to get new QR code...`);
          try {
            await this.initializeAccount(sessionId);
          } catch (error: any) {
            log(`[${sessionId}] Reinitialization failed: ${error.message}`);
          }
        }, 3000);
      });

      client.on('disconnected', async (reason: string) => {
        log(`[${sessionId}] ✗ Client disconnected: ${reason}`);
        clientState.isReady = false;
        clientState.lastError = `Disconnected: ${reason}`;

        const account = await storage.getWhatsAppAccountBySessionId(sessionId);
        if (account) {
          await storage.updateWhatsAppAccount(account.id, {
            isConnected: false,
          });
        }

        log(`[${sessionId}] Connection lost, deleting session and forcing re-initialization...`);
        
        try {
          await client.destroy();
        } catch (e: any) {
          log(`[${sessionId}] Error destroying client: ${e.message}`);
        }

        this.clients.delete(sessionId);

        try {
          const authPath = join(process.cwd(), '.wwebjs_auth', `session-${sessionId}`);
          await fs.rm(authPath, { recursive: true, force: true });
          log(`[${sessionId}] Deleted old session files`);
        } catch (error: any) {
          log(`[${sessionId}] Error deleting session files: ${error.message}`);
        }

        setTimeout(async () => {
          log(`[${sessionId}] Reinitializing to get new QR code...`);
          try {
            await this.initializeAccount(sessionId);
          } catch (error: any) {
            log(`[${sessionId}] Reinitialization failed: ${error.message}`);
          }
        }, 3000);
      });

      client.on('loading_screen', (percent: number) => {
        log(`[${sessionId}] Loading session... ${percent}%`);
      });

      await client.initialize();
      log(`[${sessionId}] Client initialization started`);
    } catch (error: any) {
      log(`[${sessionId}] ✗ Failed to initialize: ${error.message}`);
      clientState.lastError = error.message;
      clientState.initializing = false;
      throw error;
    }
  }

  async disconnectAccount(sessionId: string): Promise<void> {
    const state = this.clients.get(sessionId);
    if (!state) {
      log(`Account ${sessionId} not found`);
      return;
    }

    log(`Disconnecting account ${sessionId}`);
    
    try {
      if (state.client) {
        await state.client.destroy();
      }
    } catch (error: any) {
      log(`Error destroying client for ${sessionId}: ${error.message}`);
    }

    this.clients.delete(sessionId);

    const account = await storage.getWhatsAppAccountBySessionId(sessionId);
    if (account) {
      await storage.updateWhatsAppAccount(account.id, {
        isConnected: false,
      });
    }
  }

  async deleteAccountSession(sessionId: string): Promise<void> {
    await this.disconnectAccount(sessionId);

    try {
      const authPath = join(process.cwd(), '.wwebjs_auth', `session-${sessionId}`);
      await fs.rm(authPath, { recursive: true, force: true });
      log(`Deleted session files for ${sessionId}`);
    } catch (error: any) {
      log(`Error deleting session files for ${sessionId}: ${error.message}`);
    }
  }

  getAccountState(sessionId: string): ClientState | null {
    return this.clients.get(sessionId) || null;
  }

  getAllStates(): Map<string, ClientState> {
    return new Map(this.clients);
  }

  async sendMessage(sessionId: string, number: string, message: string): Promise<{ success: boolean; error?: string; messageId?: string }> {
    const state = this.clients.get(sessionId);
    
    if (!state || !state.client) {
      return {
        success: false,
        error: 'Account not initialized'
      };
    }

    if (!state.isReady) {
      return {
        success: false,
        error: 'Account not ready. Please scan QR code if needed.'
      };
    }

    try {
      const clientState = await state.client.getState();
      if (clientState !== 'CONNECTED') {
        return {
          success: false,
          error: `Account not connected (state: ${clientState})`
        };
      }
    } catch (error: any) {
      log(`Error checking state for ${sessionId}: ${error.message}`);
    }

    try {
      let cleanNumber = number.replace(/[^\d+]/g, '');
      if (cleanNumber.startsWith('+')) {
        cleanNumber = cleanNumber.substring(1);
      }
      
      const chatId = `${cleanNumber}@c.us`;
      log(`[${sessionId}] Sending message to ${chatId}`);
      
      const sentMessage = await state.client.sendMessage(chatId, message);
      
      log(`[${sessionId}] ✓ Message sent successfully`);
      
      const account = await storage.getWhatsAppAccountBySessionId(sessionId);
      if (account) {
        await storage.updateWhatsAppAccount(account.id, {
          lastUsedAt: new Date(),
        });
      }
      
      return {
        success: true,
        messageId: sentMessage.id.id
      };
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to send message';
      log(`[${sessionId}] ✗ Failed to send message: ${errorMessage}`);
      
      if (errorMessage.includes('phone number is not registered') || 
          errorMessage.includes('No LID for user') ||
          errorMessage.includes('is not a WhatsApp user')) {
        return {
          success: false,
          error: `Phone number ${number} is not registered on WhatsApp`
        };
      }
      
      return {
        success: false,
        error: errorMessage
      };
    }
  }

  async initializeAllAccounts(): Promise<void> {
    log('Initializing all WhatsApp accounts from storage...');
    const accounts = await storage.getAllWhatsAppAccounts();
    
    log(`Found ${accounts.length} accounts to initialize`);
    
    const initPromises = accounts.map(account => 
      this.initializeAccount(account.sessionId).catch(error => {
        log(`Failed to initialize account ${account.name} (${account.sessionId}): ${error.message}`);
      })
    );
    
    await Promise.allSettled(initPromises);
    log('All accounts initialization completed');
  }
}

export const clientsManager = new WhatsAppClientsManager();

export async function initializeAllWhatsAppAccounts() {
  await clientsManager.initializeAllAccounts();
}

export function getAccountState(sessionId: string) {
  return clientsManager.getAccountState(sessionId);
}

export function getAllAccountStates() {
  return clientsManager.getAllStates();
}

export async function initializeWhatsAppAccount(sessionId: string) {
  await clientsManager.initializeAccount(sessionId);
}

export async function disconnectWhatsAppAccount(sessionId: string) {
  await clientsManager.disconnectAccount(sessionId);
}

export async function deleteWhatsAppAccountSession(sessionId: string) {
  await clientsManager.deleteAccountSession(sessionId);
}

export async function sendMessageFromAccount(sessionId: string, number: string, message: string) {
  return await clientsManager.sendMessage(sessionId, number, message);
}
