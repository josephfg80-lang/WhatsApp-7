import { type User, type InsertUser, type ApiKey, type InsertApiKey, type WhatsAppAccount, type InsertWhatsAppAccount } from "@shared/schema";
import { randomUUID } from "crypto";
import { promises as fs } from "fs";
import { join } from "path";

const STORAGE_DIR = join(process.cwd(), ".storage");
const API_KEYS_FILE = join(STORAGE_DIR, "api_keys.json");
const WHATSAPP_ACCOUNTS_FILE = join(STORAGE_DIR, "whatsapp_accounts.json");
const BULK_SEND_PROGRESS_FILE = join(STORAGE_DIR, "bulk_send_progress.json");

export interface BulkSendProgress {
  tasks: Array<{ phone: string; message: string }>;
  currentIndex: number;
  startedAt: string;
  lastUpdatedAt: string;
}

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getApiKey(id: string): Promise<ApiKey | undefined>;
  getApiKeyByKey(key: string): Promise<ApiKey | undefined>;
  getAllApiKeys(): Promise<ApiKey[]>;
  createApiKey(apiKey: InsertApiKey): Promise<ApiKey>;
  updateApiKey(id: string, updates: Partial<InsertApiKey>): Promise<ApiKey | undefined>;
  updateApiKeyLastUsed(id: string): Promise<void>;
  deleteApiKey(id: string): Promise<boolean>;
  
  getWhatsAppAccount(id: string): Promise<WhatsAppAccount | undefined>;
  getWhatsAppAccountBySessionId(sessionId: string): Promise<WhatsAppAccount | undefined>;
  getAllWhatsAppAccounts(): Promise<WhatsAppAccount[]>;
  createWhatsAppAccount(account: InsertWhatsAppAccount): Promise<WhatsAppAccount>;
  updateWhatsAppAccount(id: string, updates: Partial<Omit<WhatsAppAccount, 'id' | 'createdAt'>>): Promise<WhatsAppAccount | undefined>;
  deleteWhatsAppAccount(id: string): Promise<boolean>;
  verifyWhatsAppAccountPassword(id: string, password: string): Promise<boolean>;
  
  getBulkSendProgress(): Promise<BulkSendProgress | null>;
  saveBulkSendProgress(progress: BulkSendProgress): Promise<void>;
  clearBulkSendProgress(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private apiKeys: Map<string, ApiKey>;
  private whatsappAccounts: Map<string, WhatsAppAccount>;
  private initialized: boolean = false;

  constructor() {
    this.users = new Map();
    this.apiKeys = new Map();
    this.whatsappAccounts = new Map();
    this.initializeStorage();
  }

  private async initializeStorage() {
    if (this.initialized) return;
    
    try {
      await fs.mkdir(STORAGE_DIR, { recursive: true });
      
      try {
        const data = await fs.readFile(API_KEYS_FILE, "utf-8");
        const keys: ApiKey[] = JSON.parse(data);
        keys.forEach((key) => {
          this.apiKeys.set(key.id, {
            ...key,
            createdAt: new Date(key.createdAt),
            lastUsedAt: key.lastUsedAt ? new Date(key.lastUsedAt) : null,
          });
        });
      } catch (error) {
        await this.saveApiKeys();
      }
      
      try {
        const data = await fs.readFile(WHATSAPP_ACCOUNTS_FILE, "utf-8");
        const accounts: WhatsAppAccount[] = JSON.parse(data);
        accounts.forEach((account) => {
          this.whatsappAccounts.set(account.id, {
            ...account,
            createdAt: new Date(account.createdAt),
            lastUsedAt: account.lastUsedAt ? new Date(account.lastUsedAt) : null,
          });
        });
      } catch (error) {
        await this.saveWhatsAppAccounts();
      }
      
      this.initialized = true;
    } catch (error) {
      console.error("Failed to initialize storage:", error);
    }
  }

  private async saveApiKeys() {
    try {
      const keys = Array.from(this.apiKeys.values());
      await fs.writeFile(API_KEYS_FILE, JSON.stringify(keys, null, 2), "utf-8");
    } catch (error) {
      console.error("Failed to save API keys:", error);
    }
  }

  private async saveWhatsAppAccounts() {
    try {
      const accounts = Array.from(this.whatsappAccounts.values());
      await fs.writeFile(WHATSAPP_ACCOUNTS_FILE, JSON.stringify(accounts, null, 2), "utf-8");
    } catch (error) {
      console.error("Failed to save WhatsApp accounts:", error);
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getApiKey(id: string): Promise<ApiKey | undefined> {
    await this.initializeStorage();
    return this.apiKeys.get(id);
  }

  async getApiKeyByKey(key: string): Promise<ApiKey | undefined> {
    await this.initializeStorage();
    return Array.from(this.apiKeys.values()).find(
      (apiKey) => apiKey.key === key,
    );
  }

  async getAllApiKeys(): Promise<ApiKey[]> {
    await this.initializeStorage();
    return Array.from(this.apiKeys.values());
  }

  async createApiKey(insertApiKey: InsertApiKey): Promise<ApiKey> {
    await this.initializeStorage();
    const id = randomUUID();
    const apiKey: ApiKey = {
      ...insertApiKey,
      id,
      isActive: insertApiKey.isActive ?? true,
      createdAt: new Date(),
      lastUsedAt: null,
    };
    this.apiKeys.set(id, apiKey);
    await this.saveApiKeys();
    return apiKey;
  }

  async updateApiKey(id: string, updates: Partial<InsertApiKey>): Promise<ApiKey | undefined> {
    await this.initializeStorage();
    const existing = this.apiKeys.get(id);
    if (!existing) return undefined;
    
    const updated: ApiKey = { ...existing, ...updates };
    this.apiKeys.set(id, updated);
    await this.saveApiKeys();
    return updated;
  }

  async updateApiKeyLastUsed(id: string): Promise<void> {
    await this.initializeStorage();
    const existing = this.apiKeys.get(id);
    if (existing) {
      existing.lastUsedAt = new Date();
      this.apiKeys.set(id, existing);
      await this.saveApiKeys();
    }
  }

  async deleteApiKey(id: string): Promise<boolean> {
    await this.initializeStorage();
    const result = this.apiKeys.delete(id);
    if (result) {
      await this.saveApiKeys();
    }
    return result;
  }

  async getBulkSendProgress(): Promise<BulkSendProgress | null> {
    try {
      const data = await fs.readFile(BULK_SEND_PROGRESS_FILE, "utf-8");
      return JSON.parse(data);
    } catch (error) {
      return null;
    }
  }

  async saveBulkSendProgress(progress: BulkSendProgress): Promise<void> {
    try {
      await fs.mkdir(STORAGE_DIR, { recursive: true });
      await fs.writeFile(BULK_SEND_PROGRESS_FILE, JSON.stringify(progress, null, 2), "utf-8");
    } catch (error) {
      console.error("Failed to save bulk send progress:", error);
    }
  }

  async clearBulkSendProgress(): Promise<void> {
    try {
      await fs.unlink(BULK_SEND_PROGRESS_FILE);
    } catch (error) {
      // File doesn't exist, ignore
    }
  }

  async getWhatsAppAccount(id: string): Promise<WhatsAppAccount | undefined> {
    await this.initializeStorage();
    return this.whatsappAccounts.get(id);
  }

  async getWhatsAppAccountBySessionId(sessionId: string): Promise<WhatsAppAccount | undefined> {
    await this.initializeStorage();
    return Array.from(this.whatsappAccounts.values()).find(
      (account) => account.sessionId === sessionId,
    );
  }

  async getAllWhatsAppAccounts(): Promise<WhatsAppAccount[]> {
    await this.initializeStorage();
    return Array.from(this.whatsappAccounts.values());
  }

  async createWhatsAppAccount(insertAccount: InsertWhatsAppAccount): Promise<WhatsAppAccount> {
    await this.initializeStorage();
    const id = randomUUID();
    const account: WhatsAppAccount = {
      ...insertAccount,
      id,
      isConnected: false,
      phoneNumber: null,
      createdAt: new Date(),
      lastUsedAt: null,
    };
    this.whatsappAccounts.set(id, account);
    await this.saveWhatsAppAccounts();
    return account;
  }

  async updateWhatsAppAccount(id: string, updates: Partial<Omit<WhatsAppAccount, 'id' | 'createdAt'>>): Promise<WhatsAppAccount | undefined> {
    await this.initializeStorage();
    const existing = this.whatsappAccounts.get(id);
    if (!existing) return undefined;
    
    const updated: WhatsAppAccount = { ...existing, ...updates };
    this.whatsappAccounts.set(id, updated);
    await this.saveWhatsAppAccounts();
    return updated;
  }

  async deleteWhatsAppAccount(id: string): Promise<boolean> {
    await this.initializeStorage();
    const result = this.whatsappAccounts.delete(id);
    if (result) {
      await this.saveWhatsAppAccounts();
    }
    return result;
  }

  async verifyWhatsAppAccountPassword(id: string, password: string): Promise<boolean> {
    await this.initializeStorage();
    const account = this.whatsappAccounts.get(id);
    if (!account) return false;
    return account.password === password;
  }
}

export const storage = new MemStorage();
